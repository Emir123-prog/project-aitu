const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const authRoutes = require('./routes/authRoutes');
const itemRoutes = require('./routes/itemRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
require('dotenv').config();  // Подключение .env для безопасного хранения конфиденциальных данных

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

// Получаем строку подключения из .env файла
const mongoDBUrl = process.env.MONGODB_URL || 'mongodb+srv://emir:1234@cluster0.cjdqo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

// Подключение к MongoDB
mongoose.connect(mongoDBUrl)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('MongoDB connection error:', err));

// Маршруты
app.use(authRoutes);
app.use(itemRoutes);
app.use(dashboardRoutes);

// Главная страница
app.get('/', (req, res) => {
    const token = req.cookies.authToken;
    if (token) return res.redirect('/dashboard');
    res.render('index');
});

// Запуск сервера
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
